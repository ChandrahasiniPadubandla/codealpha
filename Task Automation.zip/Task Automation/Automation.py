import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

def load_data(file_path):
    """Load dataset from a CSV file."""
    try:
        data = pd.read_csv(file_path)
        print("Dataset loaded successfully.")
        return data
    except FileNotFoundError:
        messagebox.showerror("Error", "File not found. Please check the file path.")
        return None

def handle_missing_values(data):
    """Handle missing values by filling them with the mean of the column for numeric data."""
    numeric_columns = data.select_dtypes(include=['float64', 'int64']).columns
    data[numeric_columns] = data[numeric_columns].fillna(data[numeric_columns].mean())
    print("Missing values handled.")
    return data

def convert_data_types(data):
    """Convert data types to appropriate formats."""
    # Example: Convert 'MSSubClass' to string
    if 'MSSubClass' in data.columns:
        data['MSSubClass'] = data['MSSubClass'].astype(str)
    print("Data types converted.")
    return data

def normalize_numeric_columns(data):
    """Normalize numeric columns using MinMaxScaler."""
    numeric_columns = data.select_dtypes(include=['float64', 'int64']).columns
    scaler = MinMaxScaler()
    data[numeric_columns] = scaler.fit_transform(data[numeric_columns])
    print("Numeric columns normalized.")
    return data

def save_cleaned_data(data, output_path):
    """Save the cleaned dataset to a new CSV file."""
    data.to_csv(output_path, index=False)
    print(f"Cleaned dataset saved to {output_path}")

def clean_data(input_file, output_file):
    data = load_data(input_file)
    if data is not None:
        data = handle_missing_values(data)
        data = convert_data_types(data)
        data = normalize_numeric_columns(data)
        save_cleaned_data(data, output_file)
        messagebox.showinfo("Success", "Data cleaning completed successfully!")

def browse_input_file():
    filename = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    input_file_var.set(filename)

def browse_output_file():
    filename = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
    output_file_var.set(filename)

def start_cleaning():
    input_file = input_file_var.get()
    output_file = output_file_var.get()
    if not input_file or not output_file:
        messagebox.showwarning("Warning", "Please select both input and output files.")
    else:
        clean_data(input_file, output_file)

def reset_fields():
    input_file_var.set("")
    output_file_var.set("")

def exit_application():
    root.destroy()

# Create the main window
root = tk.Tk()
root.title("Data Cleaning Automation")

# Input file selection
tk.Label(root, text="Input File:").grid(row=0, column=0, padx=10, pady=10)
input_file_var = tk.StringVar()
tk.Entry(root, textvariable=input_file_var, width=50).grid(row=0, column=1, padx=10, pady=10)
tk.Button(root, text="Browse", command=browse_input_file).grid(row=0, column=2, padx=10, pady=10)

# Output file selection
tk.Label(root, text="Output File:").grid(row=1, column=0, padx=10, pady=10)
output_file_var = tk.StringVar()
tk.Entry(root, textvariable=output_file_var, width=50).grid(row=1, column=1, padx=10, pady=10)
tk.Button(root, text="Browse", command=browse_output_file).grid(row=1, column=2, padx=10, pady=10)

# Buttons
tk.Button(root, text="Start Cleaning", command=start_cleaning, width=20).grid(row=2, column=1, padx=10, pady=10)
tk.Button(root, text="Reset", command=reset_fields, width=20).grid(row=3, column=0, padx=10, pady=10)
tk.Button(root, text="Exit", command=exit_application, width=20).grid(row=3, column=2, padx=10, pady=10)

# Run the main loop
root.mainloop()
