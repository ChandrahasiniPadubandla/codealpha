import tkinter as tk
import random

def choose_word():
    words = ["python", "hangman", "challenge", "programming", "openai"]
    return random.choice(words)

def display_hangman(tries):
    hangman_stages = [
        canvas.create_line(200, 200, 220, 230, fill='red'),
        canvas.create_line(200, 200, 180, 230, fill='red'),
        canvas.create_line(200, 150, 220, 180, fill='red'),
        canvas.create_line(200, 150, 180, 180, fill='red'),
        canvas.create_line(200, 140, 200, 200, fill='red'),
        canvas.create_oval(180, 100, 220, 140, outline='red'),
        canvas.create_line(200, 50, 200, 100, fill='red'),
        canvas.create_line(100, 50, 200, 50, fill='red'),
        canvas.create_line(100, 50, 100, 250, fill='red'),
        canvas.create_line(50, 250, 150, 250, fill='red'),
    ]
    for i in range(tries):
        canvas.delete(hangman_stages[i])
    for i in range(tries, 10):
        hangman_stages[i]

def guess_letter(letter):
    global tries, guessed, word_completion
    if letter in guessed_letters or letter in guessed_words:
        return
    if len(letter) == 1 and letter.isalpha():
        if letter in word:
            guessed_letters.append(letter)
            word_as_list = list(word_completion)
            indices = [i for i, l in enumerate(word) if l == letter]
            for index in indices:
                word_as_list[index] = letter
            word_completion = "".join(word_as_list)
            word_var.set(word_completion)
            if "_" not in word_completion:
                end_game(True)
        else:
            guessed_letters.append(letter)
            tries -= 1
            display_hangman(tries)
            if tries == 0:
                end_game(False)

def end_game(won):
    if won:
        result.set("Congrats, you guessed the word! You win!")
    else:
        result.set(f"Sorry, you ran out of tries. The word was '{word}'. Maybe next time!")
    for button in buttons:
        button.config(state='disabled')

def reset_game():
    global word, word_completion, guessed_letters, guessed_words, tries
    word = choose_word()
    word_completion = "_" * len(word)
    guessed_letters = []
    guessed_words = []
    tries = 10
    word_var.set(word_completion)
    result.set("")
    display_hangman(tries)
    for button in buttons:
        button.config(state='normal')

def exit_game():
    window.destroy()

def blend_color(color, alpha):
    """Blend the given color with the window background color."""
    bg_color = window.cget('bg')
    bg_rgb = window.winfo_rgb(bg_color)
    fg_rgb = window.winfo_rgb(color)
    
    blended = (
        int((1 - alpha) * bg_rgb[0] / 256 + alpha * fg_rgb[0] / 256),
        int((1 - alpha) * bg_rgb[1] / 256 + alpha * fg_rgb[1] / 256),
        int((1 - alpha) * bg_rgb[2] / 256 + alpha * fg_rgb[2] / 256)
    )
    
    # Ensure RGB values are within valid range (0-255)
    blended = tuple(max(0, min(255, x)) for x in blended)
    
    return f'#{blended[0]:02x}{blended[1]:02x}{blended[2]:02x}'

window = tk.Tk()
window.title("Hangman Game")
window.config(bg='beige')

canvas = tk.Canvas(window, width=300, height=300, bg='beige')
canvas.grid(row=0, column=0, columnspan=10)

word = choose_word()
word_completion = "_" * len(word)
guessed_letters = []
guessed_words = []
tries = 10

word_var = tk.StringVar()
word_var.set(word_completion)

word_label = tk.Label(window, textvariable=word_var, font=("Helvetica", 24), bg='beige')
word_label.grid(row=1, column=0, columnspan=10)

result = tk.StringVar()
result_label = tk.Label(window, textvariable=result, font=("Helvetica", 14), bg='beige')
result_label.grid(row=2, column=0, columnspan=10)

keyboard_frame = tk.Frame(window, bg='Gainsboro')
keyboard_frame.grid(row=3, column=0, columnspan=10)

buttons = []
letters = 'abcdefghijklmnopqrstuvwxyz'
button_style = {
    "font": ("Helvetica", 18),
    "width": 4,
    "height": 2,
    "borderwidth": 2,
    "relief": "raised",
    "highlightthickness": 0
}

alpha = 0.6  # Adjust the alpha value for transparency
blended_bg = blend_color('white', alpha)
blended_active_bg = blend_color('lightgrey', alpha)

for i, letter in enumerate(letters):
    button = tk.Button(keyboard_frame, text=letter.upper(), command=lambda l=letter: guess_letter(l), 
                       bg=blended_bg, activebackground=blended_active_bg, **button_style)
    button.grid(row=i // 10, column=i % 10, padx=2, pady=2)
    buttons.append(button)

# Add Reset and Exit buttons
control_frame = tk.Frame(window, bg='beige')
control_frame.grid(row=4, column=0, columnspan=10)

reset_button = tk.Button(control_frame, text="Reset", command=reset_game, font=("Helvetica", 18), bg="lightgrey")
reset_button.grid(row=0, column=0, padx=10, pady=10)

exit_button = tk.Button(control_frame, text="Exit", command=exit_game, font=("Helvetica", 18), bg="lightgrey")
exit_button.grid(row=0, column=1, padx=10, pady=10)

display_hangman(tries)

window.mainloop()
