import tkinter as tk
from tkinter import scrolledtext
import re

# Q&A pairs with regular expressions for matching
pairs = [
    [
        r"what is computer programming ?",
        ["Computer programming is how engineers tell a computer, application, or software program what to do. At the most basic level, programming is the process of writing a set of instructions.",]
    ],
    [
        r"how programming works ?",
        ["Once the code is written, the code is then compiled or interpreted, a process that converts source code into machine code, which is the only programming language a computer can understand. The computer then executes the code to perform the desired task.",]
    ],
    [
        r"explain the workings of a compiler ?",
        ["A compiler translates (compiles) source code written in a programming language (i.e. Java, C++, Python) into a set of machine-language instructions that can be understood by a computer.",]
    ],
    [
        r"explain debugging ?",
        ["Debugging is the process of detecting, correcting, and removing errors in source code. It starts with identifying a problem (i.e. finding a software defect), isolating the source of the problem in the code, and then correcting the problem or creating a workaround.",]
    ],
    [
        r"what is an algorithm ?",
        ["An algorithm is a set of instructions to be followed in a problem-solving operation.",]
    ],
    [
        r"types of errors ?",
        ["When the compiler finds something wrong with the program, there are three kinds of errors:\n\nSyntax Error: A syntax error occurs when the code does not follow the syntax rules of the programming language. These are the easiest errors to find and correct.\n\nRuntime Error: This is an error that takes place while running a program, causing the program to crash or hang.\n\nLogic Error: This is an error in the way that a program works (i.e. the program runs but not as expected). It is a type of runtime error that may produce the wrong output or cause a program to crash. Logic errors are the hardest to spot because they can be caused by a variety of factors.",]
    ],
    [
        r"how does a syntax error occur ?",
        ["Syntax errors can occur when you misspell a statement, or you’re missing a punctuation mark. Another possibility is using a variable before it has been declared. Missing brackets (i.e. opening a bracket but not closing it) is another common cause.",]
    ],
    [
        r"how does a runtime error occur ?",
        ["Runtime errors can occur for a variety of reasons, such as a memory leak (when a program consumes too much RAM without releasing it), programming errors, an incomplete installation, or a corrupt registry.",]
    ],
    [
        r"how does a logical error occur ?",
        ["Various programming mistakes can cause logic errors. Examples include: assigning a value to the wrong variable, incorrectly using logical operators or Boolean operators, using incorrect program design, or multiplying two numbers instead of adding them together.",]
    ],
    [
        r"what do you mean by a flowchart ?",
        ["A flowchart is a diagram that depicts a process, system, workflow, or computer algorithm. Essentially, they represent a step-by-step approach to solving a problem.",]
    ],
    [
        r"maintain and update the program ?",
        ["Software maintenance is the process of modifying and updating software that has already been published. This is done to correct faults, improve performance, and keep the program secure from cyber attacks.",]
    ],
    [
        r"define variables ?",
        ["Variables are like containers where information can be maintained and referenced. Each variable is labeled with a symbolic name that tells you what information it contains. The sole purpose of variables is to label and store data in memory.",]
    ],
    [
        r"what do you mean by reserved words ?",
        ["A reserved word is a word in a programming language that has a fixed meaning and cannot be redefined by the programmer. It may look like a “normal” word, but it cannot be used as an identifier, such as the name of a variable, function, file name, command, or label. For example, “print” is a reserved word because it is a function in many languages to show text on the screen.",]
    ],
    [
        r"explain the concept of loops ?",
        ["A loop is a sequence of instructions that are repeated until a certain condition is reached. In a loop structure, the loop asks a question (i.e. has X variable reached a value of 5?). If the answer is no, an action is executed. The question is asked again and again until no further action is required. A loop prevents programmers from having to write the same line of code over and over.",]
    ],
    [
        r"types of loops ?",
        ["There are various types of loops that can be used in high-level programming languages, such as C, C++, and C#.\n\nFOR…NEXT Loop: The FOR…NEXT loop works by running the loop a specified number of times. For example, if you ask a computer to add the integers 1-10, it would add the first two numbers, followed by a third, a fourth, and so on, until it reaches the 10th iteration.\n\nWHILE…WEND Loop: In a While…Wend loop, if the condition is true, all the statements are executed until the Wend keyword is encountered. If the condition is false, the loop is exited and the control jumps to the very next statement after the Wend keyword.\n\nNested Loop: You can nest loops by putting one loop within another. The first pass of the outer loop triggers the inner loop, which executes to completion. The second pass of the outer loop triggers the inner loop again. This process repeats until the outer loop finishes.",]
    ],
    [
        r"what do you mean by documentation ?",
        ["Documentation is the explanation of how to use and operate a piece of software. This includes information on requirements, architecture/design, technical specifications as well as instruction manuals for the end-user, system administrator, and support staff. Documentation includes requirements documents, user documentation, system documentation, process documentation, and product documentation.",]
    ],
    [
        r"what do we call the binary form of a target language ?",
        ["The binary form of a target language is also called binary code.",]
    ],
    [
        r"explain constants ?",
        ["Constants are data values that stay constant every time a program is executed. Literal constants are actual values fixed into the source code. “Named” constants are constants that have been associated with an identifier, where the constant is known by its name instead of the literal constant.\n\nNumeric Constants: A numeric constant consists of numerals, an optional leading sign, and an optional decimal point. Examples of valid numerical constants include 2.3, -4, and 6.\n\nString Constants: A string constant consists of a sequence of characters enclosed in double-quotes. It may consist of any combination of digits, letters, escaped sequences, and spaces.",]
    ],
    [
        r"what are the two types of constants ?",
        ["Numeric Constants: A numeric constant consists of numerals, an optional leading sign, and an optional decimal point. Examples of valid numerical constants include 2.3, -4, and 6.\n\nString Constants: A string constant consists of a sequence of characters enclosed in double-quotes. It may consist of any combination of digits, letters, escaped sequences, and spaces.",]
    ],
    [
        r"explain numeric constants ?",
        ["There are two types of numeric constants: integer constants and real constants. Integer constants do not have a decimal point. They can be written using decimal numbers (base 10), octal numbers (base 8), or hexadecimal numbers (Base 16) that represent an integral value. A real constant is a constant that has a decimal point. They can be written in either fractional or exponential form.",]
    ],
    [
        r"explain string constants ?",
        ["A string constant—also known as a string literal—is an arbitrary sequence of characters enclosed in double quotation marks.",]
    ],
    [
        r"what do you mean by operators ?",
        ["Operators are the backbone of every software application. An operator is a symbol that represents an action or process. This symbol tells the compiler to perform specific arithmetic or relational operations, such as adding or subtracting two numbers, to produce a final result.",]
    ],
    [
        r"define an array ?",
        ["An array is a series of “boxes” or memory locations that hold a single item of data. However, each box shares the same name. All data in an array must be the same data type.",]
    ],
    [
        r"what do you mean by subroutine ?",
        ["A subroutine designates a section of code using a specific name. Each subroutine performs a particular function—it is essentially a small program, so it can contain any of the sequence, selection, and iteration constructs. Using subroutines makes the code more readable and reusable because it breaks the code into smaller sections.",]
    ],
    [
        r"what is the use of arithmetic operators ?",
        ["Arithmetic operators are symbols that represent arithmetic operations for values or variables to compute an output. Examples include addition (+), subtraction (-), multiplication (x or *) and division (÷ or /).",]
    ],
    [
        r"what is the use of relational operators ?",
        ["A relational operator is a programming language construct or operator that tests or defines a relationship between two entities. These include numerical equality (e.g., 5 = 5) and inequalities (e.g., 4 ≥ 3). They allow computers to compare numeric and character values to determine if one is greater than, less than, or equal to another.",]
    ],
    [
        r"what do you mean by low-level programming language ?",
        ["Low-level programming languages can be converted to machine code without a compiler. The resulting code runs directly on the processor. There are two types of low-level programming languages: machine language (a series of numbers written in binary) and assembly language, which is one step closer to high-level language than machine language.",]
    ],
    [
        r"what do you mean by high-level programming language ?",
        ["High-level programming languages are human-readable programming languages that are used to write software programs and scripts. They must be converted into machine language using a compiler in order for a computer to understand the instructions, and are also closer to natural language. Examples include Python, Java, Ruby, and C#.",]
    ],
    [
        r"define machine code ?",
        ["Machine code refers to any low-level programming language consisting of machine language instructions. It is composed of hexadecimal or binary numbers and appears as a long sequence of ones and zeros. Computer programs are rarely written in machine code because doing so is tedious and error-prone. However, writing in machine code may be done for low-level debugging, program patching, and when disassembling the assembly language.",]
    ],
    [
        r"list some programming languages ?",
        ["There are over 700 programming languages, each with different use cases and platforms. Here is a list of the top 10 most common programming languages and their most common uses:\n\nPython (AI and machine learning)\nJavascript (rich interactive web development)\nJava (enterprise application development)\nR (data analysis)\nC/C++ (operating systems and system tools)\nGolang (server-side programming)\nC# (application and web development using .NET)\nPHP (web development)\nSQL (data management)\nSwift (mobile app development on iOS)",]
    ],
    [
        r"explain reliability ?",
        ["Reliability is the measure of how consistently a computer-related component (software, hardware, or a network) performs according to its specifications. Software reliability is the probability that a software program will function without failure for a specified period of time, which in turn affects system reliability. The reliability of a programming system is determined by the number of errors to be expected but also its behavior in error situations. Reliability is also an important criterion for evaluating programming languages (i.e. the extent to which the code is crash-proof).",]
    ],
    [
        r"what do you mean by modeling language ?",
        ["Unified Modeling Language (UML) is a general-purpose language that provides a standardized method for visualizing the design of a system. UML diagrams are a common visual language intended to be understood by developers and non-technical professionals alike.",]
    ],
    [
        r"what is the use case for software testing ?",
        ["Software testing is the process of checking whether a piece of software meets the requirements and is error-free. The purpose of testing is to prevent bugs, improve performance, and identify missing requirements.",]
    ],
    [
        r"explain the term beta version ?",
        ["A beta version is the pre-released version of a software program that is distributed to a large group of users, who try using the software under real-world conditions.",]
    ],
    [
        r"why do we use logical operators ?",
        ["A logical operator helps computers make decisions based on certain conditions.",]
    ],
    [
        r"what is the use case of assignment operators ?",
        ["Assignment operators are used in C/C++ to assign value to a variable using the “=” symbol. The left operand is a variable and the right operand is a value. The value on the right side must be of the same data type as the variable on the left. Otherwise, the compiler will raise an error.",]
    ],
    [
        r"what do you mean by analyzing a program ?",
        ["Program analysis is the process of evaluating the behavior of a computer program to determine if it is operating correctly. Program analysis focuses on two major areas: program optimization and program correctness. The former focuses on improving the program’s performance, while the latter ensures the program performs as intended.",]
    ],
    [
        r"how many steps does an algorithm perform ?",
        ["When we determine how long an algorithm takes to execute, we count the number of steps. Algorithms should be composed of a finite number of steps and they should complete their execution in a finite amount of time. In other words, every algorithm must reach some operation that tells it to stop.",]
    ],
    [
        r"how do you define division by zero ?",
        ["A mathematical division by zero is an illegal operation in computer programming and results in an error message (not defined). This is because zero represents a null or non-existent value. When an integer is divided by zero, this causes an interrupt on the CPU.",]
    ],
    [
        r"what does it mean to implement a program ?",
        ["Implementation is the interaction of elements in programming languages. Program implementation is the realization of technical specifications or algorithms as a program, software component, or other computer systems through computer programming and deployment.",]
    ],
    [
        r"explain numeric variables ?",
        ["A numeric variable is a variable with a numerical value. For example, the height of a cliff measured in feet is a numerical value. Numeric variables may be continuous  (they can assume an infinite number of real values within a given interval) or discrete (they can only assume a finite number of real values in a given interval).",]
    ],
    [
        r"explain string variables ?",
        ["String variables are variables that contain characters besides numbers, such as letters and symbols.",]
    ],
    [
        r"what do you mean by commands ?",
        ["A command is a unique word or phrase used to perform a specific operation. For example, “print” is a command used to display text on the screen.",]
    ],
    [
        r"how do you define the execution of a program ?",
        ["Execution is the process by which a computer reads and acts on a set of instructions needed to run a software program, script, or command. Execution occurs when the source code has been converted into machine language by a compiler, which then yields an output based on a sequence of operations.",]
    ],
    [
        r"how do you design an algorithm to count the occurrence of a word in an article ?",
        ["Use the count() function in Python.\n\nFirst, split the string by spaces and store it in a list.\nUse count() to find the count of that word in the list.",]
    ],
    [
        r"how do you implement a blocking queue in Java ?",
        ["Java provides several BlockingQueue implementations such as LinkedBlockingQueue, ArrayBlockingQueue, PriorityBlockingQueue, and SynchronousQueue.",]
    ],
    [
        r"what is a string ?",
        ["A string is a data type—such as an integer or floating-point unit—used to represent text rather than numbers.",]
    ],
    [
        r"how do you reverse a string ?",
        ["In Python, strings can be reversed using slicing. To reverse a string, simply create a slice that starts with the length of the string and ends at index 0.\n\nstringname[stringlength::-1] # method 1\nTo reverse a string without specifying the length of the string:\n\nstringname[::-1] # method2\nThe slice statement means start at string length, end at position 0, move with the step -1 (one step backward).",]
    ],
    [
        r"what is a palindrome string ?",
        ["A palindrome string occurs when the reverse of a string is the same as the original string.",]
    ],
    [
        r"how do you remove any given character from a string ?",
        ["Python: You can remove a character from a Python string using replace() or translate(). Both methods replace a character or string with a given value.\n\nJava: The replace function can be used to remove a character from a Java string. You can also use the deleteCharAt or substring method.",]
    ],
]

class ChatBot:
    def __init__(self, pairs):
        self.pairs = pairs

    def respond(self, user_input):
        for pattern, responses in self.pairs:
            match = re.match(pattern, user_input.lower())
            if match:
                return responses[0]
        return "I'm sorry, I don't understand that question."

class ChatBotGUI:
    def __init__(self, master):
        self.master = master
        master.title("ChatBot")

        self.chatbot = ChatBot(pairs)
        self.theme = "light"

        # Initialize UI components
        self.init_ui()

    def init_ui(self):
        self.chat_window = scrolledtext.ScrolledText(self.master, wrap=tk.WORD, width=60, height=20)
        self.chat_window.pack(expand=True, fill=tk.BOTH)

        self.entry_field = tk.Entry(self.master)
        self.entry_field.pack(expand=True, fill=tk.X)
        self.entry_field.bind("<Return>", self.send_message)

        # Button Frame
        self.button_frame = tk.Frame(self.master)
        self.button_frame.pack(pady=10)

        self.send_button = tk.Button(self.button_frame, text="Send", command=self.send_message)
        self.send_button.pack(side=tk.LEFT, padx=5)

        self.clear_button = tk.Button(self.button_frame, text="Clear", command=self.clear_chat)
        self.clear_button.pack(side=tk.LEFT, padx=5)

        self.exit_button = tk.Button(self.button_frame, text="Exit", command=self.exit_app)
        self.exit_button.pack(side=tk.LEFT, padx=5)

        self.theme_button = tk.Button(self.button_frame, text="🌞", command=self.switch_theme)
        self.theme_button.pack(side=tk.LEFT, padx=5)

        # Apply the initial theme
        self.apply_theme()

    def apply_theme(self):
        if self.theme == "light":
            bg_color = "white"
            fg_color = "black"
            btn_bg = "lightgray"
            btn_fg = "black"
            theme_symbol = "🌙"  # Dark theme symbol
        else:  # dark theme
            bg_color = "#2e2e2e"
            fg_color = "white"
            btn_bg = "#4a4a4a"
            btn_fg = "white"
            theme_symbol = "🌞"  # Light theme symbol

        self.master.config(bg=bg_color)
        self.chat_window.config(bg=bg_color, fg=fg_color, insertbackground=fg_color)
        self.entry_field.config(bg=btn_bg, fg=btn_fg)
        for widget in self.button_frame.winfo_children():
            widget.config(bg=btn_bg, fg=btn_fg)

        # Update the theme button symbol
        self.theme_button.config(text=theme_symbol)

    def switch_theme(self):
        self.theme = "dark" if self.theme == "light" else "light"
        self.apply_theme()

    def send_message(self, event=None):
        user_input = self.entry_field.get()
        if user_input.strip():
            self.chat_window.insert(tk.END, "You: " + user_input + "\n")
            response = self.chatbot.respond(user_input)
            self.chat_window.insert(tk.END, "ChatBot: " + response + "\n\n")
            self.entry_field.delete(0, tk.END)
            self.chat_window.yview(tk.END)  # Scroll to the end of the chat window

    def clear_chat(self):
        self.chat_window.delete(1.0, tk.END)

    def exit_app(self):
        self.master.quit()

root = tk.Tk()
my_gui = ChatBotGUI(root)
root.mainloop()